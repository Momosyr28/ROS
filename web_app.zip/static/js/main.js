// Verbindung zu ROS herstellen
var ros = new ROSLIB.Ros({ url: 'ws://' + location.hostname + ':9090' });

// CO2 Topic
var co2Topic = new ROSLIB.Topic({
  ros: ros,
  name: '/co2',
  messageType: 'std_msgs/Int32'
});
co2Topic.subscribe(function(msg) {
  document.getElementById('co2').innerText = msg.data + ' ppm';
});

// Feuchte Topic
var humidityTopic = new ROSLIB.Topic({
  ros: ros,
  name: '/humidity',
  messageType: 'std_msgs/Int32'
});
humidityTopic.subscribe(function(msg) {
  document.getElementById('humidity').innerText = msg.data + ' %';
});

// Servo-Steuerung
document.getElementById('apply-count').addEventListener('click', function() {
  var count = parseInt(document.getElementById('servo-count').value);
  var container = document.getElementById('controls');
  container.innerHTML = '';
  for (let i = 1; i <= count; i++) {
    let div = document.createElement('div');
    div.className = 'control';
    div.innerHTML = '<label>Servo ' + i + ':</label>' +
      '<input type="range" min="0" max="180" value="90" id="slider' + i + '">' +
      '<input type="number" min="0" max="180" value="90" id="input' + i + '">';
    container.appendChild(div);
    let slider = div.querySelector('#slider' + i);
    let input = div.querySelector('#input' + i);
    // Publisher für jeden Servo
    let topic = new ROSLIB.Topic({
      ros: ros,
      name: '/servo' + i + '_cmd',
      messageType: 'std_msgs/Int16'
    });
    slider.addEventListener('input', function() {
      input.value = slider.value;
      topic.publish({ data: parseInt(slider.value) });
    });
    input.addEventListener('change', function() {
      slider.value = input.value;
      topic.publish({ data: parseInt(input.value) });
    });
  }
});