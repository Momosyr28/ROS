// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from esa_src_msgs:srv/SetPwm.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "esa_src_msgs/srv/set_pwm.h"


#ifndef ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__STRUCT_H_
#define ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pwms'
#include "esa_src_msgs/msg/detail/pwm__struct.h"

/// Struct defined in srv/SetPwm in the package esa_src_msgs.
typedef struct esa_src_msgs__srv__SetPwm_Request
{
  esa_src_msgs__msg__Pwm__Sequence pwms;
} esa_src_msgs__srv__SetPwm_Request;

// Struct for a sequence of esa_src_msgs__srv__SetPwm_Request.
typedef struct esa_src_msgs__srv__SetPwm_Request__Sequence
{
  esa_src_msgs__srv__SetPwm_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} esa_src_msgs__srv__SetPwm_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/SetPwm in the package esa_src_msgs.
typedef struct esa_src_msgs__srv__SetPwm_Response
{
  bool success;
} esa_src_msgs__srv__SetPwm_Response;

// Struct for a sequence of esa_src_msgs__srv__SetPwm_Response.
typedef struct esa_src_msgs__srv__SetPwm_Response__Sequence
{
  esa_src_msgs__srv__SetPwm_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} esa_src_msgs__srv__SetPwm_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  esa_src_msgs__srv__SetPwm_Event__request__MAX_SIZE = 1
};
// response
enum
{
  esa_src_msgs__srv__SetPwm_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/SetPwm in the package esa_src_msgs.
typedef struct esa_src_msgs__srv__SetPwm_Event
{
  service_msgs__msg__ServiceEventInfo info;
  esa_src_msgs__srv__SetPwm_Request__Sequence request;
  esa_src_msgs__srv__SetPwm_Response__Sequence response;
} esa_src_msgs__srv__SetPwm_Event;

// Struct for a sequence of esa_src_msgs__srv__SetPwm_Event.
typedef struct esa_src_msgs__srv__SetPwm_Event__Sequence
{
  esa_src_msgs__srv__SetPwm_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} esa_src_msgs__srv__SetPwm_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__STRUCT_H_
