// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "esa_src_msgs/msg/pwm.h"


#ifndef ESA_SRC_MSGS__MSG__DETAIL__PWM__TYPE_SUPPORT_H_
#define ESA_SRC_MSGS__MSG__DETAIL__PWM__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "esa_src_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_esa_src_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  esa_src_msgs,
  msg,
  Pwm
)(void);

#ifdef __cplusplus
}
#endif

#endif  // ESA_SRC_MSGS__MSG__DETAIL__PWM__TYPE_SUPPORT_H_
