// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "esa_src_msgs/msg/pwm.hpp"


#ifndef ESA_SRC_MSGS__MSG__DETAIL__PWM__TRAITS_HPP_
#define ESA_SRC_MSGS__MSG__DETAIL__PWM__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "esa_src_msgs/msg/detail/pwm__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace esa_src_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Pwm & msg,
  std::ostream & out)
{
  out << "{";
  // member: pin
  {
    out << "pin: ";
    rosidl_generator_traits::value_to_yaml(msg.pin, out);
    out << ", ";
  }

  // member: value
  {
    out << "value: ";
    rosidl_generator_traits::value_to_yaml(msg.value, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Pwm & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: pin
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pin: ";
    rosidl_generator_traits::value_to_yaml(msg.pin, out);
    out << "\n";
  }

  // member: value
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "value: ";
    rosidl_generator_traits::value_to_yaml(msg.value, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Pwm & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace esa_src_msgs

namespace rosidl_generator_traits
{

[[deprecated("use esa_src_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const esa_src_msgs::msg::Pwm & msg,
  std::ostream & out, size_t indentation = 0)
{
  esa_src_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use esa_src_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const esa_src_msgs::msg::Pwm & msg)
{
  return esa_src_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<esa_src_msgs::msg::Pwm>()
{
  return "esa_src_msgs::msg::Pwm";
}

template<>
inline const char * name<esa_src_msgs::msg::Pwm>()
{
  return "esa_src_msgs/msg/Pwm";
}

template<>
struct has_fixed_size<esa_src_msgs::msg::Pwm>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<esa_src_msgs::msg::Pwm>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<esa_src_msgs::msg::Pwm>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ESA_SRC_MSGS__MSG__DETAIL__PWM__TRAITS_HPP_
