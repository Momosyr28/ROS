import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import time

try:
    import adafruit_ccs811
    import board
    import busio
except ImportError:
    print("CCS811 or board module not found. Ensure libraries are installed.")

class CO2SensorNode(Node):
    def __init__(self):
        super().__init__('co2_sensor_node')
        self.publisher_ = self.create_publisher(String, 'co2_data', 10)
        i2c = busio.I2C(board.SCL, board.SDA)
        self.ccs811 = adafruit_ccs811.CCS811(i2c)
        self.timer = self.create_timer(2.0, self.timer_callback)

    def timer_callback(self):
        try:
            co2 = self.ccs811.eco2
            tvoc = self.ccs811.tvoc
            msg = String()
            msg.data = f"CO2: {co2} ppm, TVOC: {tvoc} ppb"
            self.publisher_.publish(msg)
            self.get_logger().info(msg.data)
        except Exception as e:
            self.get_logger().error(f"Error reading sensor: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = CO2SensorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
