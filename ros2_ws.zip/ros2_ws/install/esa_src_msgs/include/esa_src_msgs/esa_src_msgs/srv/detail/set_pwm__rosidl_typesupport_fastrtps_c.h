// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from esa_src_msgs:srv/SetPwm.idl
// generated code does not contain a copyright notice
#ifndef ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "esa_src_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "esa_src_msgs/srv/detail/set_pwm__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_esa_src_msgs__srv__SetPwm_Request(
  const esa_src_msgs__srv__SetPwm_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_deserialize_esa_src_msgs__srv__SetPwm_Request(
  eprosima::fastcdr::Cdr &,
  esa_src_msgs__srv__SetPwm_Request * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_esa_src_msgs__srv__SetPwm_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_esa_src_msgs__srv__SetPwm_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_key_esa_src_msgs__srv__SetPwm_Request(
  const esa_src_msgs__srv__SetPwm_Request * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_key_esa_src_msgs__srv__SetPwm_Request(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_key_esa_src_msgs__srv__SetPwm_Request(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, esa_src_msgs, srv, SetPwm_Request)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "esa_src_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "esa_src_msgs/srv/detail/set_pwm__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_esa_src_msgs__srv__SetPwm_Response(
  const esa_src_msgs__srv__SetPwm_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_deserialize_esa_src_msgs__srv__SetPwm_Response(
  eprosima::fastcdr::Cdr &,
  esa_src_msgs__srv__SetPwm_Response * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_esa_src_msgs__srv__SetPwm_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_esa_src_msgs__srv__SetPwm_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_key_esa_src_msgs__srv__SetPwm_Response(
  const esa_src_msgs__srv__SetPwm_Response * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_key_esa_src_msgs__srv__SetPwm_Response(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_key_esa_src_msgs__srv__SetPwm_Response(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, esa_src_msgs, srv, SetPwm_Response)();

#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "esa_src_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
// already included above
// #include "esa_src_msgs/srv/detail/set_pwm__struct.h"
// already included above
// #include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_esa_src_msgs__srv__SetPwm_Event(
  const esa_src_msgs__srv__SetPwm_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_deserialize_esa_src_msgs__srv__SetPwm_Event(
  eprosima::fastcdr::Cdr &,
  esa_src_msgs__srv__SetPwm_Event * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_esa_src_msgs__srv__SetPwm_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_esa_src_msgs__srv__SetPwm_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_key_esa_src_msgs__srv__SetPwm_Event(
  const esa_src_msgs__srv__SetPwm_Event * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_key_esa_src_msgs__srv__SetPwm_Event(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_key_esa_src_msgs__srv__SetPwm_Event(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, esa_src_msgs, srv, SetPwm_Event)();

#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "rosidl_typesupport_interface/macros.h"
// already included above
// #include "esa_src_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, esa_src_msgs, srv, SetPwm)();

#ifdef __cplusplus
}
#endif

#endif  // ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
