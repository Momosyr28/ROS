// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from esa_src_msgs:srv/SetPwm.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "esa_src_msgs/srv/set_pwm.hpp"


#ifndef ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__BUILDER_HPP_
#define ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "esa_src_msgs/srv/detail/set_pwm__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace esa_src_msgs
{

namespace srv
{

namespace builder
{

class Init_SetPwm_Request_pwms
{
public:
  Init_SetPwm_Request_pwms()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::esa_src_msgs::srv::SetPwm_Request pwms(::esa_src_msgs::srv::SetPwm_Request::_pwms_type arg)
  {
    msg_.pwms = std::move(arg);
    return std::move(msg_);
  }

private:
  ::esa_src_msgs::srv::SetPwm_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::esa_src_msgs::srv::SetPwm_Request>()
{
  return esa_src_msgs::srv::builder::Init_SetPwm_Request_pwms();
}

}  // namespace esa_src_msgs


namespace esa_src_msgs
{

namespace srv
{

namespace builder
{

class Init_SetPwm_Response_success
{
public:
  Init_SetPwm_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::esa_src_msgs::srv::SetPwm_Response success(::esa_src_msgs::srv::SetPwm_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::esa_src_msgs::srv::SetPwm_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::esa_src_msgs::srv::SetPwm_Response>()
{
  return esa_src_msgs::srv::builder::Init_SetPwm_Response_success();
}

}  // namespace esa_src_msgs


namespace esa_src_msgs
{

namespace srv
{

namespace builder
{

class Init_SetPwm_Event_response
{
public:
  explicit Init_SetPwm_Event_response(::esa_src_msgs::srv::SetPwm_Event & msg)
  : msg_(msg)
  {}
  ::esa_src_msgs::srv::SetPwm_Event response(::esa_src_msgs::srv::SetPwm_Event::_response_type arg)
  {
    msg_.response = std::move(arg);
    return std::move(msg_);
  }

private:
  ::esa_src_msgs::srv::SetPwm_Event msg_;
};

class Init_SetPwm_Event_request
{
public:
  explicit Init_SetPwm_Event_request(::esa_src_msgs::srv::SetPwm_Event & msg)
  : msg_(msg)
  {}
  Init_SetPwm_Event_response request(::esa_src_msgs::srv::SetPwm_Event::_request_type arg)
  {
    msg_.request = std::move(arg);
    return Init_SetPwm_Event_response(msg_);
  }

private:
  ::esa_src_msgs::srv::SetPwm_Event msg_;
};

class Init_SetPwm_Event_info
{
public:
  Init_SetPwm_Event_info()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SetPwm_Event_request info(::esa_src_msgs::srv::SetPwm_Event::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_SetPwm_Event_request(msg_);
  }

private:
  ::esa_src_msgs::srv::SetPwm_Event msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::esa_src_msgs::srv::SetPwm_Event>()
{
  return esa_src_msgs::srv::builder::Init_SetPwm_Event_info();
}

}  // namespace esa_src_msgs

#endif  // ESA_SRC_MSGS__SRV__DETAIL__SET_PWM__BUILDER_HPP_
