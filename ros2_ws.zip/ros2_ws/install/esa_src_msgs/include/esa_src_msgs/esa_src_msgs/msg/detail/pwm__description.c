// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice

#include "esa_src_msgs/msg/detail/pwm__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_esa_src_msgs
const rosidl_type_hash_t *
esa_src_msgs__msg__Pwm__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x88, 0x31, 0xce, 0x75, 0x02, 0x84, 0xec, 0xd9,
      0x5d, 0xa4, 0xc9, 0x2f, 0x2a, 0x44, 0xaf, 0x6e,
      0xe8, 0x03, 0xad, 0x68, 0x1c, 0xd0, 0xfa, 0x02,
      0x34, 0xa8, 0xd5, 0xca, 0xf6, 0x9e, 0x48, 0x16,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char esa_src_msgs__msg__Pwm__TYPE_NAME[] = "esa_src_msgs/msg/Pwm";

// Define type names, field names, and default values
static char esa_src_msgs__msg__Pwm__FIELD_NAME__pin[] = "pin";
static char esa_src_msgs__msg__Pwm__FIELD_NAME__value[] = "value";

static rosidl_runtime_c__type_description__Field esa_src_msgs__msg__Pwm__FIELDS[] = {
  {
    {esa_src_msgs__msg__Pwm__FIELD_NAME__pin, 3, 3},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT8,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {esa_src_msgs__msg__Pwm__FIELD_NAME__value, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_UINT16,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
esa_src_msgs__msg__Pwm__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {esa_src_msgs__msg__Pwm__TYPE_NAME, 20, 20},
      {esa_src_msgs__msg__Pwm__FIELDS, 2, 2},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "uint8 pin\n"
  "uint16 value";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
esa_src_msgs__msg__Pwm__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {esa_src_msgs__msg__Pwm__TYPE_NAME, 20, 20},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 22, 22},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
esa_src_msgs__msg__Pwm__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *esa_src_msgs__msg__Pwm__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
