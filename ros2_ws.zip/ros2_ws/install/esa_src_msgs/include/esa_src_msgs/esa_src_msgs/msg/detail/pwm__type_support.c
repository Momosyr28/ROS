// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "esa_src_msgs/msg/detail/pwm__rosidl_typesupport_introspection_c.h"
#include "esa_src_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "esa_src_msgs/msg/detail/pwm__functions.h"
#include "esa_src_msgs/msg/detail/pwm__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  esa_src_msgs__msg__Pwm__init(message_memory);
}

void esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_fini_function(void * message_memory)
{
  esa_src_msgs__msg__Pwm__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_member_array[2] = {
  {
    "pin",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(esa_src_msgs__msg__Pwm, pin),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "value",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is key
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(esa_src_msgs__msg__Pwm, value),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_members = {
  "esa_src_msgs__msg",  // message namespace
  "Pwm",  // message name
  2,  // number of fields
  sizeof(esa_src_msgs__msg__Pwm),
  false,  // has_any_key_member_
  esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_member_array,  // message members
  esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_init_function,  // function to initialize message memory (memory has to be allocated)
  esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_type_support_handle = {
  0,
  &esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_members,
  get_message_typesupport_handle_function,
  &esa_src_msgs__msg__Pwm__get_type_hash,
  &esa_src_msgs__msg__Pwm__get_type_description,
  &esa_src_msgs__msg__Pwm__get_type_description_sources,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_esa_src_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, esa_src_msgs, msg, Pwm)() {
  if (!esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_type_support_handle.typesupport_identifier) {
    esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &esa_src_msgs__msg__Pwm__rosidl_typesupport_introspection_c__Pwm_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
