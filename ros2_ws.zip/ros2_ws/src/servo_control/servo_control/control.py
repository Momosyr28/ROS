import rclpy
from rclpy.node import Node
from esa_src_msgs.srv import SetPwm
import lgpio

SERVO_MIN = 500
SERVO_MAX = 2500


class ServoControlNode(Node):
    def __init__(self):
        super().__init__('servo_control_node')
        self.pwms = []
        self.srv = self.create_service(SetPwm, 'set_pwm', self.set_pwm_callback)
        self.h = lgpio.gpiochip_open(4)
        self.get_logger().error('set_pwm service created, waiting for call...')        
        

    def get_pwm(self, pin: int):
        if pin not in self.pwms:
            lgpio.gpio_claim_output(self.h, pin)
            self.pwms.append(pin)

    def set_angle(self, servo, angle):
        pulse_width = int(SERVO_MIN + (angle / 180.0) * (SERVO_MAX - SERVO_MIN))
        lgpio.tx_servo(self.h, servo, pulse_width)
        self.get_logger().info(f'Set pulse width: {pulse_width}')

    def set_pwm_callback(self, request, response):
        if not request.pwm:
            self.get_logger().warn("No PWM received")
            response.success = False
            return response

        for pwm_data in request.pwms:
            self.set_angle(pwm_data.pin, pwm_data.value)
            self.get_logger().info(f"Set servo {pwm_data.pin} to {pwm_data.value} degrees (PWM duty: {duty:.2f})")
            response.success = True

        return response

def main(args=None):
    rclpy.init(args=args)
    node = ServoControlNode()
    rclpy.spin(node)
    for pin in node.pwms:
        lgpio.gpio_release_output(node.h, pin)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
