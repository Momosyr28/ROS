// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice
#ifndef ESA_SRC_MSGS__MSG__DETAIL__PWM__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define ESA_SRC_MSGS__MSG__DETAIL__PWM__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "esa_src_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "esa_src_msgs/msg/detail/pwm__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_esa_src_msgs__msg__Pwm(
  const esa_src_msgs__msg__Pwm * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_deserialize_esa_src_msgs__msg__Pwm(
  eprosima::fastcdr::Cdr &,
  esa_src_msgs__msg__Pwm * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_esa_src_msgs__msg__Pwm(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_esa_src_msgs__msg__Pwm(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
bool cdr_serialize_key_esa_src_msgs__msg__Pwm(
  const esa_src_msgs__msg__Pwm * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t get_serialized_size_key_esa_src_msgs__msg__Pwm(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
size_t max_serialized_size_key_esa_src_msgs__msg__Pwm(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_esa_src_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, esa_src_msgs, msg, Pwm)();

#ifdef __cplusplus
}
#endif

#endif  // ESA_SRC_MSGS__MSG__DETAIL__PWM__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
