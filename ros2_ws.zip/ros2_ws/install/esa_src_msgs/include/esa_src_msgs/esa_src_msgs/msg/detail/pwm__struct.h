// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "esa_src_msgs/msg/pwm.h"


#ifndef ESA_SRC_MSGS__MSG__DETAIL__PWM__STRUCT_H_
#define ESA_SRC_MSGS__MSG__DETAIL__PWM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

/// Struct defined in msg/Pwm in the package esa_src_msgs.
typedef struct esa_src_msgs__msg__Pwm
{
  uint8_t pin;
  uint16_t value;
} esa_src_msgs__msg__Pwm;

// Struct for a sequence of esa_src_msgs__msg__Pwm.
typedef struct esa_src_msgs__msg__Pwm__Sequence
{
  esa_src_msgs__msg__Pwm * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} esa_src_msgs__msg__Pwm__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ESA_SRC_MSGS__MSG__DETAIL__PWM__STRUCT_H_
