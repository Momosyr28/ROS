// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from esa_src_msgs:msg/Pwm.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "esa_src_msgs/msg/pwm.hpp"


#ifndef ESA_SRC_MSGS__MSG__DETAIL__PWM__BUILDER_HPP_
#define ESA_SRC_MSGS__MSG__DETAIL__PWM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "esa_src_msgs/msg/detail/pwm__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace esa_src_msgs
{

namespace msg
{

namespace builder
{

class Init_Pwm_value
{
public:
  explicit Init_Pwm_value(::esa_src_msgs::msg::Pwm & msg)
  : msg_(msg)
  {}
  ::esa_src_msgs::msg::Pwm value(::esa_src_msgs::msg::Pwm::_value_type arg)
  {
    msg_.value = std::move(arg);
    return std::move(msg_);
  }

private:
  ::esa_src_msgs::msg::Pwm msg_;
};

class Init_Pwm_pin
{
public:
  Init_Pwm_pin()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Pwm_value pin(::esa_src_msgs::msg::Pwm::_pin_type arg)
  {
    msg_.pin = std::move(arg);
    return Init_Pwm_value(msg_);
  }

private:
  ::esa_src_msgs::msg::Pwm msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::esa_src_msgs::msg::Pwm>()
{
  return esa_src_msgs::msg::builder::Init_Pwm_pin();
}

}  // namespace esa_src_msgs

#endif  // ESA_SRC_MSGS__MSG__DETAIL__PWM__BUILDER_HPP_
